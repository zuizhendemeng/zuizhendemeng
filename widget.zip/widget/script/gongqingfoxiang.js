$("button").click(function(){
 
  var dataqingfoxiang=$(this).attr("id");
  var data_foid=$(this).attr("name");
  //alert(data_foid);
 /*   if(dataqingfoxiang == null){
   alert("您还没有恭请佛像！");
   }else{
   isFirst_fo=true;
   } */
  //$("#lifo_gongqingfoxiang").attr("src", "../image/"+dataqingfoxiang+".png");
 // alert(dataqingfoxiang);
 // $("#toPagenews").attr("href","news.html?data="+"1"+dataqingfoxiang);
   window.location.href='news.html?data='+dataqingfoxiang+'&foid='+data_foid;// 跳转到news.html
 
  });

