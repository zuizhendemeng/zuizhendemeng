
var a1,a2,a3,a4;
$(function () {

            //方法二：
            (function ($) {
                $.getUrlParam = function (name) {
                //alert(name);
                    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
                    var r = window.location.search.substr(1).match(reg);
                    if (r != null) return decodeURI(r[2]); return null;          //在此解析汉子编码，否则汉字总是以乱码出现
                   //  if (r != null) return unescape(r[2]); return null;
                }
            })(jQuery);

            //方法二：
           // var xx = $.getUrlParam('data');
//
          //方法一：
            // var xx = getUrlParam('reurl');


          //  alert("xx"+xx);

        });
       $(document).ready(function(){
        a1 = $.getUrlParam('fotypeflag');
        a2 = $.getUrlParam('xiangtypeflag');
        a3 = $.getUrlParam('huatypeflag');
        a4 = $.getUrlParam('guotypeflag');
      // alert(a1); alert(a2); alert(a3);   alert(a4);
       
        
       
       });
        
        
function CheckForm()
{

	if(document.myform.Name.value==''){
      alert('请填写你的姓名！');
       document.myform.GuestContent.focus();
      return(false) ;
    }
	if(document.myform.age.value==''){
      alert('请填写你的年龄！');
       document.myform.GuestContent.focus();
      return(false) ;
    }
	if(document.myform.address.value==''){
      alert('请填写你的联系地址！');
       document.myform.GuestContent.focus();
      return(false) ;
    }
	if(document.myform.GuestTitle.value==''){
      alert('祈愿的主题不能为空！');
       document.myform.GuestTitle.focus();
      return(false) ;
    }
      document.myform.GuestTitle.value='供敬'+a1+'供奉'+a2+a3+a4+'祈愿---'+document.myform.GuestTitle.value;
    //  alert(document.myform.GuestTitle.value);
  if(document.myform.GuestContent.value==''){
    alert('内容不能为空！');
    document.myform.GuestContent.focus();
    return(false);
  }
  if(document.myform.GuestContent.value.length>65536){
    alert('内容不能超过64K！');
     document.myform.GuestContent.focus();
    return(false);
  }
}
 /*
function myFunction()
{
 api.showProgress();//显示加载进度框
		//使用api.ajax请求数据，具体使用方法和参数请看官方文档，这里使用get方法演示
		api.ajax({
		url:'http://wzt.28ms.com/lifo1/savejingfo.php',//如果地址访问不到会请求出错，请填写自己的接口地址
		method:'get',
		cache:'false',
		timeout:30,
		dataTpye:'json',
		},function(ret,err){
		api.hideProgress();//隐藏加载进度框
		// var result_fo ="";
		  for(var i=0;i<ret.length;i++){ 
		   alert('ddd');
		if(ret[0].reg_fh == 2){
		window.location.href = 'bless.html';
		
			//alert(ret[0]["guesttitle"]);
			
		
			 var name_fo=ret[i].name;
			var age_fo=ret[i].age;
			var time_fo=ret[i].up_time;
			//var html='祈福：'+ret[i].guesttitle+'姓名：'+ret[i].name+'年龄:'+ret[i].age+'留言时间'+ret[i].up_time;
			//document.write(html);
			//api.alert({msg:html});
			//document.write("title_fo");
			//alert(title_fo);
		
		//result_fo=result_fo+"<tr class='Guest_tdbgfo'>"+
			//  "<td align='center'><div align='left'><p>"+ret[i].guesttitle+"</p></div></td><td width='10%' align='center'>"+ret[i].name+"</td><td width='11%' align='center'>"+ret[i].age+
			//  "</td><td width=17% align=left><div align=center>"+ret[i].up_time+"</div></td></tr>";
			
			// alert(result_fo);
		
			 
	 	
			
			 
			//  $("#Guest_tdbg").html(result_fo);
			// =result_fo;
		   }else{
		api.alert({msg:('错误码：'+err.code+'；错误信息：'+err.msg+'网络状态码：'+err.statusCode)});
		}
	}
		});
}

$(document).ready(function(){
  
       $("#publish").click(function(){
         publish_flag=1;
         return publish_flag;
    }); 
    if(pulish_flag==1){
     window.location.href='bless.html';
    }else{
    return false;
    }
       });  */
       
