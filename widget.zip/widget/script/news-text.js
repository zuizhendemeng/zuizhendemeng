/*
 
alert("请先恭请佛像和选择贡品，然后许愿");*/
//修行香的选择
 var isFirst_fo =  false;
 var yy;
 var xiangtypeflag;
 var huatypeflag;
 var guotypeflag;
 $(function () {

            //方法二：
            (function ($) {
                $.getUrlParam = function (name) {
                //alert(name);
                    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
                    var r = window.location.search.substr(1).match(reg);
                  //  if (r != null) return decodeURI(r[2]); return null;          //在此解析汉子编码，否则汉字总是以乱码出现
                     if (r != null) return decodeURI(r[2]); return null;
                }
            })(jQuery);

            //方法二：
           // var xx = $.getUrlParam('data');
//
          //方法一：
            // var xx = getUrlParam('reurl');


          //  alert("xx"+xx);

        });
            
$(document).ready(function(){
  
  // var dataqingfoxiang=$(this).attr("id");
  // var xx = $.getUrlParam('data');
     var xx = $.getUrlParam('data');
     yy =encodeURI($.getUrlParam('foid'));
      //alert(yy);
  // alert (xx);
  //xx不为空
   if(!(xx == undefined)){
    isFirst_fo=true;
  //  alert(isFirst_fo);
  
 // alert (xx);
    $("#lifo_gongqingfoxiang").attr("src", "../image/"+xx+".png");  
   }else{
//  alert("请恭请佛像！");
       return true;
   }
  // $.url().param('data');
   
  // $("#lifo_gongqingfoxiang").attr("src", "../image/"+foxiang_type+".png");
   //   alert("数据：" +$.url().param('data'));

  });

 $(document).ready(function(){ 
 
   var isFirst = false;
  var xiang_flag = false;
  var hua_flag = false;
  var guo_flag = false;
  var isFirst_hua = false;
  var isFirst_guo = false;
 
 
 
 
  $("#xiuxing_xiang").click(function(){
  
  if(isFirst==true&&xiang_flag==true){
       alert("您已恭请供品,要经常更换供品恭敬菩萨，也要避免浪费供品，阿弥陀佛！");
  }else{
         if(isFirst_fo==false){
         alert("请先恭请佛像！");
         }else{
  if(hua_flag ==false && isFirst_hua == true){
  $("#layer4_jingfo div").hide(); 
   }else if(guo_flag ==false && isFirst_guo == true){
   $("#layer5_jingfo div").hide();
   }else{
   $("#layer4_jingfo div").hide(); 
   $("#layer5_jingfo div").hide();
   }
  $("#layer3_jingfo div").fadeIn();
  $("#layer3_jingfo div").click(function(){
  var xiang_type=$(this).attr("id");
  $("#xiang").attr("src", "../image/"+xiang_type+".png");
  $("#layer3_jingfo").hide();
    xiang_flag = true;
  });

  /*  
    */
    isFirst = true;
   
  }
         }

    });  
/*以下是花瓶的选择*/

    $(".xiuxing_huaping").click(function(){
    if(isFirst_hua==true&& hua_flag==true){
       alert("您已恭请鲜花,要经常更换供品恭敬菩萨，也要避免浪费供品，阿弥陀佛！");
  }else{
             if(isFirst_fo==false){
         alert("请先恭请佛像！");
         }else{
    if(xiang_flag==false && isFirst == true){
    $("#layer3_jingfo div").hide();
    }else if(guo_flag == false && isFirst_guo == true){
    $("#layer5_jingfo div").hide();
    }else {
   $("#layer3_jingfo div").hide(); 
   $("#layer5_jingfo div").hide();
   }
    $("#layer4_jingfo div").fadeIn();
 
  $("#layer4_jingfo div").click(function(){
  var hua_type=$(this).attr("id");
 
  $("#huaping_1").attr("src", "../image/"+hua_type+".png");
  $("#huaping_2").attr("src", "../image/"+hua_type+".png");
  $("#layer4_jingfo").hide();
    hua_flag = true;
  });
   
    isFirst_hua = true;
  } 
               }
});
/*以下是水果*/
    
    $(".xiuxing_fruit").click(function(){
  if(isFirst_guo==true && guo_flag==true){
       alert("您已恭请供果,要经常更换供品恭敬菩萨，也要避免浪费供品，阿弥陀佛！");
  }else{
                     if(isFirst_fo==false){
         alert("请先恭请佛像！");
         }else{
       if(isFirst == true && xiang_flag == false){
       $("#layer3_jingfo div").hide();
       }else if(isFirst_hua == true && hua_flag == false){
       $("#layer4_jingfo div").hide();
       }else{
   $("#layer3_jingfo div").hide(); 
   $("#layer4_jingfo div").hide();
   }
             $("#layer5_jingfo div").fadeIn();
             $("#layer5_jingfo div").click(function(){
             var guo_type=$(this).attr("id");
             $("#fruit_1").attr("src", "../image/"+guo_type+".png");
             $("#fruit_2").attr("src", "../image/"+guo_type+".png");
             $("#layer5_jingfo").hide();  
             guo_flag = true;
  });

   isFirst_guo = true;
  } 
                                     }
 });
  
    $("#layer3_jingfo img").click(function(){
   
    xiangtypeflag = encodeURI($(this).attr("id"));
   
    }); 
 

  $("#layer4_jingfo img").click(function(){
      huatypeflag =encodeURI($(this).attr("id"));
  });

  $("#layer5_jingfo img").click(function(){
      guotypeflag = $(this).attr("id");
  });
  
  
   $("#xiuxing_cup").click(function(){
   if(xiang_flag==true && hua_flag==true && guo_flag ==true && isFirst_fo ==true){
   alert("已经恭请佛像，贡品已经选择，请许愿！"); 
    window.location.href='online_wish.html?fotypeflag='+yy+'&xiangtypeflag='+xiangtypeflag+'&huatypeflag='+huatypeflag+'&guotypeflag='+guotypeflag; // 跳转到online_wish.html
    return true;
   } else{
  alert("请恭请佛像，选择完全供品!"); 
  return(false);
  }
  
// window.location.href='news.html?data='+dataqingfoxiang;  

//$("button").click(function(){
 
  //var dataqingfoxiang=$(this).attr("id");
  //  if(dataqingfoxiang == null){
  // alert("您还没有恭请佛像！");
   //}else{
   //isFirst_fo=true;
   //}
  //$("#lifo_gongqingfoxiang").attr("src", "../image/"+dataqingfoxiang+".png");
 // alert(dataqingfoxiang);
 // $("#toPagenews").attr("href","news.html?data="+"1"+dataqingfoxiang);
  // window.location.href='news.html?data='+dataqingfoxiang; // 跳转到news.html
 
 // });

});

 

 });
/* 
$(document).ready(function(){
 $("input").click(function(){
  
   
  var foxiang_type=$(this).attr("id");
  $("#lifo_gongqingfoxiang").attr("src", "../image/"+foxiang_type+".png");
   window.location.href='news.html?foid='+foxiang_type; // 跳转到wish.html
   
  });
}); 
 function submit_foxiang(){
   window.location.href='news.html'; // 跳转到wish.html
   } */