function showJingfoInfo(){
		api.showProgress();//显示加载进度框
		//使用api.ajax请求数据，具体使用方法和参数请看官方文档，这里使用get方法演示
		api.ajax({
		url:'http://wzt.28ms.com/lifo1/jingfo.php',//如果地址访问不到会请求出错，请填写自己的接口地址
		method:'get',
		cache:'false',
		timeout:30,
		dataTpye:'json',
		},function(ret,err){
		api.hideProgress();//隐藏加载进度框
		 var result_fo ="";
		  
		if(ret){
			//alert(ret[0]["guesttitle"]);
			for(var i=0;i<ret.length;i++){
		
			/*var name_fo=ret[i].name;
			var age_fo=ret[i].age;
			var time_fo=ret[i].up_time;*/
			//var html='祈福：'+ret[i].guesttitle+'姓名：'+ret[i].name+'年龄:'+ret[i].age+'留言时间'+ret[i].up_time;	
			//document.write(html);
			//api.alert({msg:html});
			//document.write("title_fo");
			//alert(title_fo);
		
		result_fo=result_fo+"<tr class='Guest_tdbgfo'>"+
			  "<td align='center'><div align='left'><p>"+ret[i].guesttitle+"</p></div></td><td width='10%' align='center'>"+ret[i].name+"</td><td width='11%' align='center'>"+ret[i].age+
			  "</td><td width=17% align=left><div align=center>"+ret[i].up_time+"</div></td></tr>";
			
			// alert(result_fo);
		
				/*  */
			}
			
			 
			  $("#Guest_tdbg").html(result_fo);
			// =result_fo;
		   }else{
		api.alert({msg:('错误码：'+err.code+'；错误信息：'+err.msg+'网络状态码：'+err.statusCode)});
		}
		 
		});
	
	}


                         
                            